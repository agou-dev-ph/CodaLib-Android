# CodaLib — Batch 1 UI implementation

This build implements the first visual redesign of CodaLib using Kotlin and Android Views.

## Included in this batch
- CodaLib adaptive launcher icon using the plum, violet, and emerald identity.
- Dark plum interface with violet folder accents and emerald file-type accents.
- Compact detailed file list with name, size, type, and modified date.
- Sidebar with horizontal icon-only quick access for Home, Favorites, Images, Documents, and Downloads.
- Search by file and folder name recursively within the currently selected folder.
- Sort by name, size, type, and modified date; filter by file category.
- Long-press multi-selection with copy, move, share, and delete actions.
- Item menus with open, rename, copy, move, favorite, details, and delete.
- Bottom information bar showing folder/file counts and listed size, or selection count and size.
- Empty-folder message in the file-list area.
- Text-file preview inside CodaLib; external chooser for other supported formats.
- Persistent starting-folder selection through Android's Storage Access Framework.

## Build
Requires JDK 17, Android SDK Platform 35, Build Tools 35.0.0, and Gradle 8.9.
Run `gradle assembleDebug` from this project directory.

GitHub Actions workflow: **Build CodaLib APK**. The resulting artifact is **CodaLib-Batch1-UI-APK**.

## Notes
- This is an initial UI implementation and should be tested on the target Android device before merging.
- The light theme and full adaptive theme switching are not implemented yet; this batch uses the approved dark plum theme.
- Tablet sidebar behavior is width-aware; phone sidebar opens from the menu control.
- Android's document provider controls which folders can be selected and accessed.
- The app uses Kotlin/Java only and includes no native `.so` libraries, so it is not restricted to ARM64 and can run on supported ARMv7 and ARM64 Android devices. Minimum Android version is 8.0 (API 26).
