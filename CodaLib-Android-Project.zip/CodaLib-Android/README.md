# CodaLib Android — Batch 1.1

Batch 1.1 is a functionality and UI refinement pass on the first CodaLib visual prototype.

## Included in this update
- Predictable phone drawer overlay with outside-tap dismissal; persistent collapsible sidebar on wide layouts.
- Recursive folder tree with expandable levels and retained expanded-folder state while the activity remains open.
- Parent-folder Back navigation for folders opened from the file list and reconstructed navigation for sidebar tree selections.
- Quick Access shortcuts for Home, Favorites, Images, Documents, and Downloads (Downloads is resolved within the selected starting folder).
- Recursive Images and Documents shortcuts, plus Favorites resolution for SAF tree/document URIs.
- Responsive file-list columns on narrow displays.
- More recognizable minimal file-type glyphs.
- Text preview for common text formats, capped at 1 MB; other files open through Android's app chooser.
- Multi-item copy, move, and share support. Move deletes originals only after every selected item has copied successfully. Name collisions fail safely rather than overwrite.
- Dark, light, system-default, and emerald/violet accent appearance preferences applied on activity creation.
- More accurate listed-size and device-free-space labels; recursive folder size in item details.

## Storage access
CodaLib uses Android's Storage Access Framework and a user-selected starting folder. Access remains limited to the folder tree granted by Android. Downloads, Images, and Documents shortcuts only search within that selected tree.

## Build
The project is built by the repository's GitHub Actions workflow using Java 17, Android SDK 35, and Gradle. The workflow expects the project archive at repository root as `CodaLib-Android-Project.zip`.

## Known limitations
- The project has not been compiled in this environment; GitHub Actions must verify the build.
- Search is synchronous and capped to avoid unbounded traversal; a cancellable background search remains future work.
- Recursive folder size and shortcut scans can take time on very large trees.
- Copy operations run on a worker thread but do not yet expose detailed per-file progress or cancellation.
- Storage free space reports the device data partition, not necessarily the selected SD card or external provider.
- Android storage providers differ in rename, delete, and directory-copy support.
- Text previews are limited to the first 1 MB and decode as UTF-8.
- No thumbnails are generated; file-type icons are used by design.
