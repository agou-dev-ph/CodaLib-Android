# CodaLib Android project

A scoped-storage file manager starter with a compact list-and-toolbar workflow inspired by file/archive managers such as ZArchiver. It does not use ZArchiver branding or assets.

## Features
- Select one folder with Android's system folder picker and persist access.
- Browse within that selected folder tree.
- Create folders/files; rename, delete, copy, move, and open items in other apps.
- Does not request `MANAGE_EXTERNAL_STORAGE` or unrestricted all-files access.

## Current limitations
- Android's picker decides which folders can be granted; protected system locations may be unavailable.
- Move is implemented as copy-then-delete. Name collisions and provider behavior can vary.
- The first version's Back action returns to the selected root, rather than reconstructing each parent.
- Opening source files depends on an installed editor that accepts Android content URIs.

## Build an APK using GitHub from your phone
1. Create a GitHub account and a new repository named `CodaLib-Android`.
2. Extract this ZIP and upload the *contents* of the project into the repository.
3. Open the repository's Actions tab.
4. Run **Build CodaLib APK** (or push to the `main` branch).
5. Open the completed workflow run and download the `CodaLib-debug-apk` artifact.
6. Extract that artifact ZIP and install `app-debug.apk`. Android may ask permission to install apps from your browser.

## Local build
Requires JDK 17, Android SDK Platform 35, and Gradle 8.9. Run `gradle assembleDebug`.
Application ID: `com.codalib.app`.

## Starting folder and CPU architecture
- On first launch, choose a starting folder with Android's system folder picker. You can select a location exposed by Android, such as internal shared storage or an SD card.
- CodaLib saves the folder permission and restores the selected location after future launches. Use the overflow menu to change the starting folder.
- Android may prevent selecting protected locations such as `Android/data` and `Android/obb`.
- This project contains Kotlin/Java code and no bundled native `.so` libraries. Its APK is not tied to ARM64: it can run on supported 32-bit ARM (`armeabi-v7a`) and 64-bit ARM (`arm64-v8a`) Android devices, subject to the Android version requirement (`minSdk 26`).
