plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.codalib.app"
    compileSdk = 35
    defaultConfig { applicationId = "com.codalib.app"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
kotlin {
    jvmToolchain(17)
}
dependencies {
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.core:core-ktx:1.15.0")
}
