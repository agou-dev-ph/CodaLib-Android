package com.codalib.app

import android.app.*
import android.content.*
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import android.graphics.Color
import android.os.StatFs
import androidx.documentfile.provider.DocumentFile
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private var plum = 0xFF120C1F.toInt()
    private var surface = 0xFF1B1429.toInt()
    private var surface2 = 0xFF241B35.toInt()
    private var violet = 0xFF8B5CF6.toInt()
    private var violetSoft = 0xFFA78BFA.toInt()
    private var emerald = 0xFF10B981.toInt()
    private var emeraldSoft = 0xFF6EE7B7.toInt()
    private var fg = 0xFFF4F0FA.toInt()
    private var muted = 0xFFB7ADC7.toInt()
    private var line = 0xFF382B4A.toInt()
    private val pickCode = 41
    private val prefs by lazy { getSharedPreferences("codalib", MODE_PRIVATE) }

    private lateinit var rootLayout: FrameLayout
    private lateinit var drawerScrim: View
    private lateinit var sidebar: LinearLayout
    private lateinit var mainPanel: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var pathLabel: TextView
    private lateinit var bottomInfo: TextView
    private lateinit var toolbarTitle: TextView
    private lateinit var searchBox: EditText
    private lateinit var selectionBar: LinearLayout
    private var rootUri: Uri? = null
    private var current: DocumentFile? = null
    private var clipItems: List<DocumentFile> = emptyList()
    private var moveClip = false
    private var sidebarVisible = false
    private var selectionMode = false
    private val selected = linkedSetOf<Uri>()
    private var currentItems = listOf<DocumentFile>()
    private var sortField = "name"
    private var descending = false
    private var filter = "All"
    private var searchQuery = ""
    private var favorites = mutableSetOf<String>()
    private val expandedFolders = mutableSetOf<String>()
    private val folderStack = mutableListOf<DocumentFile>()
    private var showingFavorites = false
    private var showingShortcut: String? = null
    private val isWide get() = resources.configuration.screenWidthDp >= 700
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        favorites = prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()
        applySavedTheme()
        buildUi()
        restoreStartingFolder()
    }

    private fun shape(color: Int, radius: Int = 12): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun buildUi() {
        rootLayout = FrameLayout(this).apply { setBackgroundColor(plum) }
        mainPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(plum) }
        val mainParams = FrameLayout.LayoutParams(-1, -1)
        if (isWide) mainParams.leftMargin = dp(244)
        rootLayout.addView(mainPanel, mainParams)
        drawerScrim = View(this).apply {
            setBackgroundColor(0x99000000.toInt()); visibility = View.GONE
            setOnClickListener { closeSidebar() }
        }
        if (!isWide) rootLayout.addView(drawerScrim, FrameLayout.LayoutParams(-1, -1))
        sidebar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(16), dp(12), dp(12)); setBackgroundColor(surface); elevation = dp(12).toFloat() }
        buildSidebar()
        val sideParams = FrameLayout.LayoutParams(dp(244), -1, Gravity.START)
        rootLayout.addView(sidebar, sideParams)
        sidebarVisible = isWide
        sidebar.visibility = if (isWide) View.VISIBLE else View.GONE
        buildMain()
        window.statusBarColor = surface
        window.navigationBarColor = plum
        if (plum == 0xFFF7F5FA.toInt()) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        else window.decorView.systemUiVisibility = 0
        setContentView(rootLayout)
    }

    private fun buildSidebar() {
        sidebar.removeAllViews()
        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(4), dp(4), dp(20)) }
        val mark = TextView(this).apply { text = "◇"; textSize = 30f; setTextColor(violet); gravity = Gravity.CENTER; background = shape(surface2, 12) }
        brand.addView(mark, LinearLayout.LayoutParams(dp(42), dp(42)))
        val name = LinearLayout(this).apply { orientation = 1; setPadding(dp(10), 0, 0, 0) }
        name.addView(text("CodaLib", 19f, fg, true)); name.addView(text("FILE EXPLORER", 9f, muted, true))
        brand.addView(name); sidebar.addView(brand)
        sidebar.addView(text("QUICK ACCESS", 10f, muted, true).apply { setPadding(dp(6), dp(10), 0, dp(8)) })
        val shortcuts = listOf("Home" to "⌂", "Favorites" to "☆", "Images" to "▧", "Documents" to "▤", "Downloads" to "↓")
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(10)) }
        shortcuts.forEach { (label, glyph) ->
            val b = TextView(this).apply { text = glyph; textSize = 19f; gravity = Gravity.CENTER; setTextColor(if (showingShortcut == label || (label == "Favorites" && showingFavorites)) violetSoft else fg); background = shape(surface2, 10); contentDescription = label; setOnClickListener { openShortcut(label) } }
            quick.addView(b, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
        }
        sidebar.addView(quick)
        sidebar.addView(text("FOLDERS", 10f, muted, true).apply { setPadding(dp(6), dp(10), 0, dp(8)) })
        val root = TextView(this).apply { text = "⌂  Starting folder"; textSize = 13f; setTextColor(fg); setPadding(dp(8), dp(10), 0, dp(10)); setOnClickListener { goToRoot() } }
        sidebar.addView(root)
        rootUri?.let { uri -> DocumentFile.fromTreeUri(this@MainActivity, uri)?.let { rootFolder -> expandedFolders.add(rootFolder.uri.toString()); addFolderTree(rootFolder, 0, 4) } }
        val spacer = View(this); sidebar.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        sidebar.addView(text("CodaLib · v1.1", 10f, muted).apply { setPadding(dp(6), dp(12), 0, dp(4)) })
    }

    private fun buildMain() {
        mainPanel.removeAllViews()
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(10), dp(8)); setBackgroundColor(surface) }
        toolbar.addView(toolButton("☰") { toggleSidebar() })
        val titleWrap = LinearLayout(this).apply { orientation = 1; setPadding(dp(8), 0, 0, 0) }
        toolbarTitle = text("CodaLib", 17f, fg, true)
        pathLabel = text("Choose a starting folder", 10f, muted)
        titleWrap.addView(toolbarTitle); titleWrap.addView(pathLabel)
        toolbar.addView(titleWrap, LinearLayout.LayoutParams(0, -2, 1f))
        toolbar.addView(toolButton("⌕") { searchBox.requestFocus(); (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showSoftInput(searchBox, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT) })
        toolbar.addView(toolButton("＋") { createMenu() })
        toolbar.addView(toolButton("⋮") { moreMenu() })
        mainPanel.addView(toolbar)
        searchBox = EditText(this).apply { hint = "Search this folder and subfolders"; textSize = 13f; setTextColor(fg); setHintTextColor(muted); setSingleLine(true); background = shape(surface2, 10); setPadding(dp(12), 0, dp(12), 0); visibility = View.GONE }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { searchQuery = s?.toString().orEmpty(); refreshListOnly() }
            override fun afterTextChanged(s: Editable?) {}
        })
        mainPanel.addView(searchBox, LinearLayout.LayoutParams(-1, dp(42)).apply { setMargins(dp(12), dp(8), dp(12), dp(4)) })
        selectionBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(6), dp(12), dp(6)); visibility = View.GONE; setBackgroundColor(surface2) }
        mainPanel.addView(selectionBar)
        val tableHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(16), dp(9), dp(12), dp(9)); setBackgroundColor(surface) }
        tableHead.addView(text("NAME", 9f, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        tableHead.addView(text("SIZE", 9f, muted, true), LinearLayout.LayoutParams(dp(if (resources.configuration.screenWidthDp < 380) 48 else 62), -2))
        tableHead.addView(text("TYPE", 9f, muted, true), LinearLayout.LayoutParams(dp(if (resources.configuration.screenWidthDp < 380) 48 else 60), -2))
        if (resources.configuration.screenWidthDp >= 380) tableHead.addView(text("MODIFIED", 9f, muted, true), LinearLayout.LayoutParams(dp(82), -2))
        mainPanel.addView(tableHead)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        mainPanel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        bottomInfo = text("Choose a folder to begin", 10f, muted).apply { setPadding(dp(12), dp(9), dp(12), dp(9)); setBackgroundColor(surface); gravity = Gravity.CENTER_VERTICAL }
        mainPanel.addView(bottomInfo)
    }

    private fun toolButton(glyph: String, action: () -> Unit): TextView = TextView(this).apply {
        text = glyph; textSize = 22f; gravity = Gravity.CENTER; setTextColor(fg); background = shape(surface2, 10); setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(4) }
    }

    private fun toggleSidebar() {
        if (isWide) {
            sidebarVisible = !sidebarVisible
            sidebar.visibility = if (sidebarVisible) View.VISIBLE else View.GONE
            (mainPanel.layoutParams as FrameLayout.LayoutParams).apply { leftMargin = if (sidebarVisible) dp(244) else 0; mainPanel.layoutParams = this }
        } else if (sidebarVisible) closeSidebar() else {
            sidebarVisible = true; drawerScrim.visibility = View.VISIBLE; sidebar.visibility = View.VISIBLE; sidebar.bringToFront()
        }
    }

    private fun closeSidebar() {
        if (isWide) return
        sidebarVisible = false; sidebar.visibility = View.GONE; drawerScrim.visibility = View.GONE
    }

    private fun goToRoot() {
        val root = rootUri?.let { DocumentFile.fromTreeUri(this, it) } ?: return
        current = root; folderStack.clear(); showingFavorites = false; showingShortcut = null; closeSidebar(); refresh()
    }

    private fun rebuildFolderStack(target: DocumentFile) {
        folderStack.clear()
        val root = rootUri?.let { DocumentFile.fromTreeUri(this, it) } ?: return
        fun find(parent: DocumentFile, wanted: Uri, path: MutableList<DocumentFile>, depth: Int): Boolean {
            if (depth > 16) return false
            val children = runCatching { parent.listFiles().filter { it.isDirectory } }.getOrDefault(emptyList())
            for (child in children) {
                if (child.uri == wanted) { path.add(parent); return true }
                path.add(parent)
                if (find(child, wanted, path, depth + 1)) return true
                path.removeAt(path.lastIndex)
            }
            return false
        }
        val path = mutableListOf<DocumentFile>()
        if (find(root, target.uri, path, 0)) folderStack.addAll(path)
    }

    private fun addFolderTree(folder: DocumentFile, depth: Int, maxDepth: Int) {
        if (depth >= maxDepth) return
        val key = folder.uri.toString()
        val expanded = expandedFolders.contains(key)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4 + depth * 12), dp(2), 0, dp(2)) }
        val toggle = TextView(this).apply { text = if (expanded) "▾" else "▸"; textSize = 13f; setTextColor(violetSoft); gravity = Gravity.CENTER; setOnClickListener { if (expanded) expandedFolders.remove(key) else expandedFolders.add(key); buildSidebar() } }
        row.addView(toggle, LinearLayout.LayoutParams(dp(24), dp(34)))
        val name = TextView(this).apply { text = "▰  ${folder.name ?: "Folder"}"; textSize = 12f; setTextColor(if (current?.uri == folder.uri) violetSoft else fg); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE; gravity = Gravity.CENTER_VERTICAL; setOnClickListener { current = folder; rebuildFolderStack(folder); showingFavorites = false; showingShortcut = null; closeSidebar(); refresh() } }
        row.addView(name, LinearLayout.LayoutParams(0, dp(34), 1f)); sidebar.addView(row)
        if (expanded) runCatching { folder.listFiles().filter { it.isDirectory }.sortedBy { it.name?.lowercase(Locale.getDefault()) }.take(100) }.getOrDefault(emptyList()).forEach { addFolderTree(it, depth + 1, maxDepth) }
    }

    private fun openShortcut(label: String) {
        showingShortcut = label; showingFavorites = label == "Favorites"
        searchQuery = ""; if (::searchBox.isInitialized) searchBox.setText("")
        if (label == "Home" || label == "Images" || label == "Documents" || label == "Downloads") {
            current = rootUri?.let { DocumentFile.fromTreeUri(this, it) }; showingFavorites = false
        }
        if (label == "Downloads") {
            val root = current
            val download = root?.findFile("Download") ?: root?.findFile("Downloads")
            if (download != null && download.isDirectory) current = download else { showingShortcut = null; toast("Downloads folder was not found inside the selected starting folder") }
        }
        closeSidebar(); buildSidebar(); refresh()
    }

    private fun chooseFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, pickCode)
    }

    private fun restoreStartingFolder() {
        val saved = prefs.getString("tree_uri", null)
        if (saved.isNullOrBlank()) { showChooseLocationMessage(); return }
        try {
            val uri = Uri.parse(saved)
            val allowed = contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
            val restored = DocumentFile.fromTreeUri(this, uri)
            if (!allowed || restored == null || !restored.canRead()) { clearStartingFolder(); showChooseLocationMessage("Folder access is unavailable. Choose it again."); return }
            rootUri = uri; current = restored; buildSidebar(); refresh()
        } catch (_: Exception) { clearStartingFolder(); showChooseLocationMessage("Couldn't reopen the saved folder. Choose it again.") }
    }

    private fun clearStartingFolder() { rootUri = null; current = null; prefs.edit().remove("tree_uri").apply() }

    private fun showChooseLocationMessage(message: String = "Choose a starting folder to browse files.") {
        list.removeAllViews()
        val empty = LinearLayout(this).apply { orientation = 1; gravity = Gravity.CENTER; setPadding(dp(24), dp(48), dp(24), dp(48)) }
        empty.addView(text("◇", 42f, violet).apply { gravity = Gravity.CENTER })
        empty.addView(text(message, 14f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(16)) })
        val choose = Button(this).apply { text = "Choose starting folder"; setOnClickListener { chooseFolder() } }
        empty.addView(choose)
        list.addView(empty, LinearLayout.LayoutParams(-1, -1))
        pathLabel.text = "No folder selected"; bottomInfo.text = "Storage access is controlled by Android"
    }

    @Deprecated("Compatibility with Android folder picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickCode && resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!; val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            try {
                contentResolver.takePersistableUriPermission(uri, flags)
                val folder = DocumentFile.fromTreeUri(this, uri)
                if (folder == null || !folder.canRead()) { toast("CodaLib couldn't access that folder."); return }
                rootUri = uri; current = folder; folderStack.clear(); prefs.edit().putString("tree_uri", uri.toString()).apply(); showingFavorites = false; showingShortcut = null
                buildSidebar(); refresh(); toast("Starting folder saved")
            } catch (_: Exception) { toast("Folder access couldn't be saved. Choose it again.") }
        } else if (requestCode == pickCode && current == null) showChooseLocationMessage("Selection cancelled. Choose a starting folder to continue.")
    }

    private fun refresh() {
        current?.let { dir -> pathLabel.text = dir.name ?: "Storage"; toolbarTitle.text = if (showingFavorites) "Favorites" else showingShortcut ?: "Files" }
        buildSidebar(); refreshListOnly()
    }

    private fun refreshListOnly() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val dir = current
        if (dir == null) { showChooseLocationMessage(); return }
        var items: List<DocumentFile> = if (showingFavorites) favorites.mapNotNull { raw ->
            val uri = Uri.parse(raw)
            runCatching { DocumentFile.fromTreeUri(this, uri) }.getOrNull()
                ?: runCatching { DocumentFile.fromSingleUri(this, uri) }.getOrNull()
        }.filter { it.exists() }
        else runCatching { dir.listFiles().toList() }.getOrDefault(emptyList())
        if (!showingFavorites && (showingShortcut == "Images" || showingShortcut == "Documents")) {
            val all = mutableListOf<DocumentFile>(); collectAll(dir, all); items = all
        }
        if (searchQuery.isNotBlank()) {
            val found = mutableListOf<DocumentFile>(); collectMatches(dir, searchQuery.lowercase(Locale.getDefault()), found)
            items = found
        }
        if (showingShortcut == "Images") items = items.filter { !it.isDirectory && category(it) == "Images" }
        if (showingShortcut == "Documents") items = items.filter { !it.isDirectory && category(it) == "Documents" }
        items = items.filter { filter == "All" || category(it) == filter }
        items = when (sortField) {
            "size" -> items.sortedBy { it.length() }
            "type" -> items.sortedBy { it.type ?: "" }
            "date" -> items.sortedBy { it.lastModified() }
            else -> items.sortedBy { it.name?.lowercase(Locale.getDefault()) ?: "" }
        }
        items = items.sortedWith(compareBy<DocumentFile>({ !it.isDirectory }, {
            when (sortField) {
                "size" -> it.length().toString().padStart(20, '0')
                "type" -> it.type ?: ""
                "date" -> it.lastModified().toString().padStart(20, '0')
                else -> it.name?.lowercase(Locale.getDefault()) ?: ""
            }
        }))
        if (descending) {
            val folders = items.filter { it.isDirectory }; val files = items.filter { !it.isDirectory }
            items = folders.reversed() + files.reversed()
        }
        currentItems = items
        if (items.isEmpty()) {
            val msg = if (searchQuery.isNotBlank()) "No matching files or folders" else if (showingFavorites) "No favorites yet" else "This folder is empty"
            list.addView(text(msg, 13f, muted).apply { gravity = Gravity.CENTER; setPadding(dp(20), dp(54), dp(20), dp(54)) }, LinearLayout.LayoutParams(-1, -2))
        } else items.forEach { addRow(it) }
        val files = items.count { !it.isDirectory }; val folders = items.count { it.isDirectory }
        val used = items.filter { !it.isDirectory }.sumOf { it.length() }
        val selectedFiles = currentItems.filter { selected.contains(it.uri) }
        val selectedSize = selectedFiles.sumOf { it.length() }
        bottomInfo.text = if (selectionMode) "${selected.size} selected · ${fmt(selectedSize)}" else "$folders folders · $files files  •  Listed ${fmt(used)}  •  Storage: ${storageSummary()}"
        updateSelectionBar()
    }

    private fun collectAll(dir: DocumentFile, out: MutableList<DocumentFile>, depth: Int = 0) {
        if (depth > 12 || out.size > 5000) return
        val children = runCatching { dir.listFiles() }.getOrDefault(emptyArray())
        children.forEach { child -> out.add(child); if (child.isDirectory) collectAll(child, out, depth + 1) }
    }

    private fun collectMatches(dir: DocumentFile, query: String, out: MutableList<DocumentFile>, depth: Int = 0) {
        if (depth > 12 || out.size > 2000) return
        val children = runCatching { dir.listFiles() }.getOrDefault(emptyArray())
        children.forEach { f ->
            if ((f.name ?: "").lowercase(Locale.getDefault()).contains(query)) out.add(f)
            if (f.isDirectory) collectMatches(f, query, out, depth + 1)
        }
    }

    private fun addRow(file: DocumentFile) {
        val isSelected = selected.contains(file.uri)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(4), dp(8), dp(4)); setBackgroundColor(if (isSelected) 0xFF302247.toInt() else plum) }
        val glyph = TextView(this).apply { text = if (file.isDirectory) "▰" else fileGlyph(file.name ?: ""); textSize = 19f; gravity = Gravity.CENTER; setTextColor(if (file.isDirectory) violetSoft else emeraldSoft) }
        row.addView(glyph, LinearLayout.LayoutParams(dp(34), dp(36)))
        val nameColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(5), 0, dp(4), 0) }
        nameColumn.addView(text(file.name ?: "Unnamed", 12f, fg).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE })
        nameColumn.addView(text(if (file.isDirectory) "Folder" else mimeLabel(file.name ?: ""), 9f, muted))
        row.addView(nameColumn, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text(if (file.isDirectory) "—" else fmt(file.length()), 9f, muted), LinearLayout.LayoutParams(dp(if (resources.configuration.screenWidthDp < 380) 48 else 62), -2))
        row.addView(text(if (file.isDirectory) "Folder" else extension(file.name ?: ""), 9f, emeraldSoft).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(dp(if (resources.configuration.screenWidthDp < 380) 48 else 60), -2))
        if (resources.configuration.screenWidthDp >= 380) {
            val date = if (file.lastModified() > 0) DateFormat.getDateInstance(DateFormat.SHORT).format(Date(file.lastModified())) else "—"
            row.addView(text(date, 9f, muted), LinearLayout.LayoutParams(dp(82), -2))
        }
        row.addView(TextView(this).apply { text = "⋮"; textSize = 19f; gravity = Gravity.CENTER; setTextColor(muted); setOnClickListener { fileMenu(file) } }, LinearLayout.LayoutParams(dp(24), dp(36)))
        row.setOnClickListener {
            if (selectionMode) toggleSelection(file) else if (file.isDirectory) { current?.let { folderStack.add(it) }; current = file; showingFavorites = false; showingShortcut = null; buildSidebar(); refresh() } else open(file)
        }
        row.setOnLongClickListener { if (!selectionMode) selectionMode = true; toggleSelection(file); true }
        list.addView(row)
        list.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun toggleSelection(file: DocumentFile) {
        if (selected.contains(file.uri)) selected.remove(file.uri) else selected.add(file.uri)
        if (selected.isEmpty()) selectionMode = false
        refreshListOnly()
    }

    private fun updateSelectionBar() {
        selectionBar.removeAllViews()
        selectionBar.visibility = if (selectionMode) View.VISIBLE else View.GONE
        if (!selectionMode) return
        selectionBar.addView(text("${selected.size} selected", 12f, fg, true), LinearLayout.LayoutParams(0, -2, 1f))
        listOf("Copy", "Move", "Share", "Delete", "✕").forEach { action ->
            val b = TextView(this).apply { text = action; textSize = 10f; setTextColor(violetSoft); setPadding(dp(6), dp(8), dp(6), dp(8)); setOnClickListener {
                val targets = currentItems.filter { selected.contains(it.uri) }
                when (action) {
                    "Copy" -> { clipItems = targets.toList(); moveClip = false; toast("Select a destination, then Paste here") }
                    "Move" -> { clipItems = targets.toList(); moveClip = true; toast("Select a destination, then Paste here") }
                    "Share" -> shareItems(targets)
                    "Delete" -> deleteSelected(targets)
                    else -> { selected.clear(); selectionMode = false; refreshListOnly() }
                }
            } }
            selectionBar.addView(b)
        }
    }

    private fun fileGlyph(name: String): String = when (extension(name)) {
        "jpg", "jpeg", "png", "webp", "gif", "bmp", "svg" -> "▧"
        "mp4", "mkv", "mov", "avi" -> "▶"
        "mp3", "wav", "flac", "m4a" -> "♫"
        "pdf" -> "▤"; "doc", "docx", "txt", "md", "rtf" -> "≡"
        "xls", "xlsx", "csv" -> "▦"; "ppt", "pptx" -> "▥"
        "zip", "7z", "rar", "tar", "gz" -> "▧"
        "apk" -> "◇"; "py", "html", "css", "js", "kt", "java" -> "⌘"
        else -> "•"
    }
    private fun extension(name: String) = name.substringAfterLast('.', "FILE").uppercase(Locale.getDefault()).take(5)
    private fun mimeLabel(name: String) = extension(name).lowercase(Locale.getDefault()).let { if (it == "file") "File" else it.uppercase() }
    private fun category(f: DocumentFile): String {
        val e = extension(f.name ?: "").lowercase(Locale.getDefault())
        return when (e) {
            "jpg", "jpeg", "png", "webp", "gif", "bmp", "svg" -> "Images"
            "mp4", "mkv", "mov", "avi", "mp3", "wav", "flac", "m4a" -> "Media"
            "pdf", "doc", "docx", "txt", "md", "rtf", "xls", "xlsx", "ppt", "pptx" -> "Documents"
            "zip", "7z", "rar", "tar", "gz" -> "Archives"
            else -> "Other"
        }
    }
    private fun directorySize(folder: DocumentFile, depth: Int = 0): Long {
        if (depth > 20) return 0L
        return runCatching { folder.listFiles().sumOf { if (it.isDirectory) directorySize(it, depth + 1) else it.length() } }.getOrDefault(0L)
    }

    private fun storageSummary(): String = try {
        val stat = StatFs(android.os.Environment.getDataDirectory().path)
        "${fmt(stat.availableBytes)} free"
    } catch (_: Exception) { "unavailable" }

    private fun fmt(b: Long) = when { b < 1024 -> "$b B"; b < 1048576 -> String.format(Locale.US, "%.1f KB", b / 1024.0); else -> String.format(Locale.US, "%.1f MB", b / 1048576.0) }

    private fun createMenu() = AlertDialog.Builder(this).setTitle("Create").setItems(arrayOf("New folder", "New file")) { _, w -> nameDialog(w == 0) }.show()
    private fun nameDialog(folder: Boolean) {
        val input = EditText(this).apply { hint = if (folder) "Folder name" else "example.txt" }
        AlertDialog.Builder(this).setTitle(if (folder) "New folder" else "New file").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Create") { _, _ ->
            val n = input.text.toString().trim(); if (n.isNotBlank() && !n.contains("/")) { val made = if (folder) current?.createDirectory(n) else current?.createFile("text/plain", n); if (made == null) toast("Could not create item") else refresh() }
        }.show()
    }

    private fun fileMenu(f: DocumentFile) {
        val actions = arrayListOf("Open", "Rename", "Copy", "Move", "Add to Favorites", "Details", "Delete")
        if (favorites.contains(f.uri.toString())) actions[4] = "Remove from Favorites"
        AlertDialog.Builder(this).setTitle(f.name ?: "Item").setItems(actions.toTypedArray()) { _, w -> when (actions[w]) {
            "Open" -> if (f.isDirectory) { current?.let { folderStack.add(it) }; current = f; showingFavorites = false; showingShortcut = null; refresh() } else open(f)
            "Rename" -> rename(f)
            "Copy" -> { clipItems = listOf(f); moveClip = false; toast("Navigate to a destination, then choose Paste here") }
            "Move" -> { clipItems = listOf(f); moveClip = true; toast("Navigate to a destination, then choose Paste here") }
            "Add to Favorites", "Remove from Favorites" -> { if (!favorites.add(f.uri.toString())) favorites.remove(f.uri.toString()); prefs.edit().putStringSet("favorites", favorites).apply(); refresh() }
            "Details" -> AlertDialog.Builder(this).setTitle(f.name).setMessage("Type: ${if (f.isDirectory) "Folder" else f.type ?: "Unknown"}\nSize: ${fmt(f.length())}\nModified: ${Date(f.lastModified())}\nLocation: ${f.uri}").setPositiveButton("Close", null).show()
            "Delete" -> AlertDialog.Builder(this).setMessage("Delete ${f.name}?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> if (f.delete()) refresh() else toast("Delete failed") }.show()
        } }.show()
    }

    private fun rename(f: DocumentFile) {
        val input = EditText(this).apply { setText(f.name ?: "") }
        AlertDialog.Builder(this).setTitle("Rename").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ -> val n = input.text.toString().trim(); if (n.isNotBlank() && !n.contains("/") && !f.renameTo(n)) toast("Rename failed") else refresh() }.show()
    }

    private fun moreMenu() {
        val choices = arrayOf("Search", "Sort by", "Filter by type", "Paste here", "Change starting folder", "Go to starting folder", "Refresh", "Settings")
        AlertDialog.Builder(this).setTitle("CodaLib").setItems(choices) { _, w -> when (w) {
            0 -> { searchBox.visibility = View.VISIBLE; searchBox.requestFocus() }
            1 -> AlertDialog.Builder(this).setTitle("Sort by").setItems(arrayOf("Name", "Size", "Type", "Date modified", "Reverse order")) { _, s -> if (s == 4) descending = !descending else { sortField = arrayOf("name", "size", "type", "date")[s]; descending = false }; refreshListOnly() }.show()
            2 -> AlertDialog.Builder(this).setTitle("Filter by type").setItems(arrayOf("All", "Images", "Documents", "Media", "Archives", "Other")) { _, s -> filter = arrayOf("All", "Images", "Documents", "Media", "Archives", "Other")[s]; refreshListOnly() }.show()
            3 -> paste()
            4 -> chooseFolder()
            5 -> { current = rootUri?.let { DocumentFile.fromTreeUri(this, it) }; showingFavorites = false; showingShortcut = null; refresh() }
            6 -> refresh()
            7 -> settingsMenu()
        } }.show()
    }

    private fun settingsMenu() {
        AlertDialog.Builder(this).setTitle("Appearance").setItems(arrayOf("System default", "Dark", "Light", "Accent: Violet", "Accent: Emerald")) { _, w ->
            val choice = arrayOf("system", "dark", "light", "violet", "emerald")[w]
            prefs.edit().putString("theme", choice).apply()
            recreate()
        }.show()
    }

    private fun applySavedTheme() {
        val choice = prefs.getString("theme", "dark") ?: "dark"
        val night = when (choice) {
            "light" -> false
            "system" -> (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
            else -> true
        }
        if (night) {
            plum = 0xFF120C1F.toInt(); surface = 0xFF1B1429.toInt(); surface2 = 0xFF241B35.toInt(); fg = 0xFFF4F0FA.toInt(); muted = 0xFFB7ADC7.toInt(); line = 0xFF382B4A.toInt()
        } else {
            plum = 0xFFF7F5FA.toInt(); surface = 0xFFFFFFFF.toInt(); surface2 = 0xFFEDE8F5.toInt(); fg = 0xFF21172F.toInt(); muted = 0xFF746A80.toInt(); line = 0xFFE2DCEB.toInt()
        }
        if (choice == "emerald") { violet = 0xFF10B981.toInt(); violetSoft = 0xFF34D399.toInt() } else { violet = 0xFF8B5CF6.toInt(); violetSoft = 0xFFA78BFA.toInt() }
        emerald = 0xFF10B981.toInt(); emeraldSoft = 0xFF6EE7B7.toInt()
    }

    private fun paste() {
        val sources = clipItems
        if (sources.isEmpty()) { toast("Clipboard is empty"); return }
        val dst = current ?: return
        if (sources.any { src -> src.uri == dst.uri || (src.isDirectory && dst.uri.toString().startsWith(src.uri.toString())) }) { toast("Invalid destination"); return }
        Thread {
            var allOk = true
            sources.forEach { src ->
                if (!copyInto(src, dst)) allOk = false
            }
            runOnUiThread {
                if (allOk && moveClip) {
                    val deleted = sources.all { it.delete() }
                    if (!deleted) toast("Copied, but one or more originals could not be deleted") else toast("Move complete")
                    clipItems = emptyList()
                } else if (allOk) toast("Copy complete") else toast("Some items could not be copied. Originals were kept.")
                refresh()
            }
        }.start()
    }

    private fun copyInto(src: DocumentFile, dst: DocumentFile): Boolean {
        val name = src.name ?: return false
        if (dst.findFile(name) != null) return false
        if (src.isDirectory) {
            val target = dst.createDirectory(name) ?: return false
            val children = runCatching { src.listFiles().toList() }.getOrElse { target.delete(); return false }
            val success = children.all { copyInto(it, target) }
            if (!success) target.delete()
            return success
        }
        val target = dst.createFile(src.type ?: mimeFromName(name), name) ?: return false
        return try {
            val input = contentResolver.openInputStream(src.uri) ?: throw IllegalStateException("No input stream")
            val output = contentResolver.openOutputStream(target.uri) ?: throw IllegalStateException("No output stream")
            input.use { ins -> output.use { outs -> ins.copyTo(outs) } }
            true
        } catch (_: Exception) { target.delete(); false }
    }

    private fun shareItems(items: List<DocumentFile>) {
        if (items.isEmpty()) return
        try {
            val streams = ArrayList<Uri>().apply { items.forEach { add(it.uri) } }
            val intent = if (streams.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, streams[0]) else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, streams)
            intent.type = if (items.size == 1) items[0].type ?: mimeFromName(items[0].name ?: "") else "*/*"
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "Share ${items.size} item(s)"))
        } catch (_: Exception) { toast("Couldn't share these items") }
    }

    private fun deleteSelected(items: List<DocumentFile>) {
        AlertDialog.Builder(this).setMessage("Delete ${items.size} selected items?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
            val ok = items.all { it.delete() }; selected.clear(); selectionMode = false; refresh(); if (!ok) toast("Some items could not be deleted")
        }.show()
    }

    private fun open(f: DocumentFile) {
        try {
            val mime = f.type?.takeIf { it != "application/octet-stream" } ?: mimeFromName(f.name ?: "")
            if (mime.startsWith("text/")) {
                val content = contentResolver.openInputStream(f.uri)?.use { stream ->
                    val bytes = stream.readNBytes(1024 * 1024)
                    String(bytes, Charsets.UTF_8) + if (bytes.size >= 1024 * 1024) "\n\n[Preview limited to first 1 MB]" else ""
                } ?: ""
                val viewer = TextView(this).apply { text = content; textSize = 13f; setTextColor(fg); setPadding(dp(14), dp(10), dp(14), dp(10)); setTextIsSelectable(true) }
                val scroll = ScrollView(this).apply { addView(viewer) }
                AlertDialog.Builder(this).setTitle(f.name ?: "Text file").setView(scroll).setPositiveButton("Close", null).show()
            } else {
                val intent = Intent(Intent.ACTION_VIEW).setDataAndType(f.uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(intent, "Open with"))
            }
        } catch (_: Exception) { toast("No compatible viewer is installed or the file couldn't be opened") }
    }

    private fun mimeFromName(name: String): String = when (name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
        "txt", "md", "py", "html", "css", "json", "xml", "kt", "java", "csv", "log" -> "text/plain"
        "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"; "gif" -> "image/gif"; "webp" -> "image/webp"
        "pdf" -> "application/pdf"; "zip" -> "application/zip"; "mp3" -> "audio/mpeg"; "mp4" -> "video/mp4"
        else -> "*/*"
    }

    override fun onBackPressed() {
        if (selectionMode) { selected.clear(); selectionMode = false; refreshListOnly(); return }
        if (sidebarVisible && !isWide) { sidebar.visibility = View.GONE; sidebarVisible = false; return }
        if (folderStack.isNotEmpty()) { current = folderStack.removeAt(folderStack.lastIndex); showingFavorites = false; showingShortcut = null; refresh(); return }
        val root = rootUri?.let { DocumentFile.fromTreeUri(this, it) }
        if (current != null && root != null && current!!.uri != root.uri) { current = root; refresh() } else super.onBackPressed()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
