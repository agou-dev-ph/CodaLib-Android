package com.codalib.app

import android.app.*
import android.content.*
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val plum = 0xFF120C1F.toInt()
    private val surface = 0xFF1B1429.toInt()
    private val surface2 = 0xFF241B35.toInt()
    private val violet = 0xFF8B5CF6.toInt()
    private val violetSoft = 0xFFA78BFA.toInt()
    private val emerald = 0xFF10B981.toInt()
    private val emeraldSoft = 0xFF6EE7B7.toInt()
    private val fg = 0xFFF4F0FA.toInt()
    private val muted = 0xFFB7ADC7.toInt()
    private val line = 0xFF382B4A.toInt()
    private val pickCode = 41
    private val prefs by lazy { getSharedPreferences("codalib", MODE_PRIVATE) }

    private lateinit var rootLayout: LinearLayout
    private lateinit var sidebar: LinearLayout
    private lateinit var mainPanel: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var pathLabel: TextView
    private lateinit var bottomInfo: TextView
    private lateinit var toolbarTitle: TextView
    private lateinit var searchBox: EditText
    private lateinit var selectionBar: LinearLayout
    private var rootUri: Uri? = null
    private var current: DocumentFile? = null
    private var clip: DocumentFile? = null
    private var moveClip = false
    private var sidebarVisible = false
    private var selectionMode = false
    private val selected = linkedSetOf<Uri>()
    private var currentItems = listOf<DocumentFile>()
    private var sortField = "name"
    private var descending = false
    private var filter = "All"
    private var searchQuery = ""
    private var favorites = mutableSetOf<String>()
    private var showingFavorites = false
    private var showingShortcut: String? = null
    private val isWide get() = resources.configuration.screenWidthDp >= 700
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        favorites = prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()
        buildUi()
        restoreStartingFolder()
    }

    private fun shape(color: Int, radius: Int = 12): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun buildUi() {
        rootLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(plum) }
        sidebar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(16), dp(12), dp(12)); setBackgroundColor(surface) }
        buildSidebar()
        mainPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(plum) }
        rootLayout.addView(sidebar, LinearLayout.LayoutParams(dp(236), -1))
        rootLayout.addView(mainPanel, LinearLayout.LayoutParams(0, -1, 1f))
        buildMain()
        sidebarVisible = isWide
        sidebar.visibility = if (sidebarVisible) View.VISIBLE else View.GONE
        setContentView(rootLayout)
    }

    private fun buildSidebar() {
        sidebar.removeAllViews()
        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(4), dp(4), dp(20)) }
        val mark = TextView(this).apply { text = "◇"; textSize = 30f; setTextColor(violet); gravity = Gravity.CENTER; background = shape(surface2, 12) }
        brand.addView(mark, LinearLayout.LayoutParams(dp(42), dp(42)))
        val name = LinearLayout(this).apply { orientation = 1; setPadding(dp(10), 0, 0, 0) }
        name.addView(text("CodaLib", 19f, fg, true)); name.addView(text("FILE EXPLORER", 9f, muted, true))
        brand.addView(name); sidebar.addView(brand)
        sidebar.addView(text("QUICK ACCESS", 10f, muted, true).apply { setPadding(dp(6), dp(10), 0, dp(8)) })
        val shortcuts = listOf("Home" to "⌂", "Favorites" to "☆", "Images" to "▧", "Documents" to "▤", "Downloads" to "⇩")
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(10)) }
        shortcuts.forEach { (label, glyph) ->
            val b = TextView(this).apply { text = glyph; textSize = 19f; gravity = Gravity.CENTER; setTextColor(if (showingShortcut == label || (label == "Favorites" && showingFavorites)) violetSoft else fg); background = shape(surface2, 10); contentDescription = label; setOnClickListener { openShortcut(label) } }
            quick.addView(b, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
        }
        sidebar.addView(quick)
        sidebar.addView(text("FOLDERS", 10f, muted, true).apply { setPadding(dp(6), dp(10), 0, dp(8)) })
        val root = TextView(this).apply { text = "▾  Internal Storage"; textSize = 13f; setTextColor(fg); setPadding(dp(8), dp(10), 0, dp(10)); setOnClickListener { current = rootUri?.let { DocumentFile.fromTreeUri(this@MainActivity, it) }; showingFavorites = false; showingShortcut = null; refresh() } }
        sidebar.addView(root)
        current?.let { dir ->
            val children = runCatching { dir.listFiles().filter { it.isDirectory }.take(30) }.getOrDefault(emptyList())
            children.forEach { folder ->
                val row = TextView(this).apply { text = "    ▸  ${folder.name ?: "Folder"}"; textSize = 12f; setTextColor(violetSoft); setPadding(dp(8), dp(8), 0, dp(8)); maxLines = 1; setOnClickListener { current = folder; showingFavorites = false; showingShortcut = null; refresh() } }
                sidebar.addView(row)
            }
        }
        val spacer = View(this); sidebar.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        sidebar.addView(text("CodaLib · v1.1", 10f, muted).apply { setPadding(dp(6), dp(12), 0, dp(4)) })
    }

    private fun buildMain() {
        mainPanel.removeAllViews()
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(10), dp(8)); setBackgroundColor(surface) }
        toolbar.addView(toolButton("☰") { toggleSidebar() })
        val titleWrap = LinearLayout(this).apply { orientation = 1; setPadding(dp(8), 0, 0, 0) }
        toolbarTitle = text("CodaLib", 17f, fg, true)
        pathLabel = text("Choose a starting folder", 10f, muted)
        titleWrap.addView(toolbarTitle); titleWrap.addView(pathLabel)
        toolbar.addView(titleWrap, LinearLayout.LayoutParams(0, -2, 1f))
        toolbar.addView(toolButton("⌕") { searchBox.requestFocus(); (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showSoftInput(searchBox, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT) })
        toolbar.addView(toolButton("＋") { createMenu() })
        toolbar.addView(toolButton("⋮") { moreMenu() })
        mainPanel.addView(toolbar)
        searchBox = EditText(this).apply { hint = "Search this folder and subfolders"; textSize = 13f; setTextColor(fg); setHintTextColor(muted); setSingleLine(true); background = shape(surface2, 10); setPadding(dp(12), 0, dp(12), 0); visibility = View.GONE }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { searchQuery = s?.toString().orEmpty(); refreshListOnly() }
            override fun afterTextChanged(s: Editable?) {}
        })
        mainPanel.addView(searchBox, LinearLayout.LayoutParams(-1, dp(42)).apply { setMargins(dp(12), dp(8), dp(12), dp(4)) })
        selectionBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(6), dp(12), dp(6)); visibility = View.GONE; setBackgroundColor(surface2) }
        mainPanel.addView(selectionBar)
        val tableHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(16), dp(9), dp(12), dp(9)); setBackgroundColor(surface) }
        tableHead.addView(text("NAME", 9f, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        tableHead.addView(text("SIZE", 9f, muted, true), LinearLayout.LayoutParams(dp(62), -2))
        tableHead.addView(text("TYPE", 9f, muted, true), LinearLayout.LayoutParams(dp(60), -2))
        tableHead.addView(text("MODIFIED", 9f, muted, true), LinearLayout.LayoutParams(dp(82), -2))
        mainPanel.addView(tableHead)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        mainPanel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        bottomInfo = text("Choose a folder to begin", 10f, muted).apply { setPadding(dp(12), dp(9), dp(12), dp(9)); setBackgroundColor(surface); gravity = Gravity.CENTER_VERTICAL }
        mainPanel.addView(bottomInfo)
    }

    private fun toolButton(glyph: String, action: () -> Unit): TextView = TextView(this).apply {
        text = glyph; textSize = 22f; gravity = Gravity.CENTER; setTextColor(fg); background = shape(surface2, 10); setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(4) }
    }

    private fun toggleSidebar() {
        if (isWide) { sidebarVisible = !sidebarVisible; sidebar.visibility = if (sidebarVisible) View.VISIBLE else View.GONE }
        else {
            if (sidebar.parent == null) return
            if (sidebarVisible) { sidebar.visibility = View.GONE; sidebarVisible = false }
            else { sidebar.visibility = View.VISIBLE; sidebarVisible = true; sidebar.bringToFront() }
        }
    }

    private fun openShortcut(label: String) {
        showingShortcut = label; showingFavorites = label == "Favorites"
        searchQuery = ""; if (::searchBox.isInitialized) searchBox.setText("")
        if (label == "Home") { current = rootUri?.let { DocumentFile.fromTreeUri(this, it) }; showingFavorites = false }
        buildSidebar(); refresh()
    }

    private fun chooseFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, pickCode)
    }

    private fun restoreStartingFolder() {
        val saved = prefs.getString("tree_uri", null)
        if (saved.isNullOrBlank()) { showChooseLocationMessage(); return }
        try {
            val uri = Uri.parse(saved)
            val allowed = contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
            val restored = DocumentFile.fromTreeUri(this, uri)
            if (!allowed || restored == null || !restored.canRead()) { clearStartingFolder(); showChooseLocationMessage("Folder access is unavailable. Choose it again."); return }
            rootUri = uri; current = restored; buildSidebar(); refresh()
        } catch (_: Exception) { clearStartingFolder(); showChooseLocationMessage("Couldn't reopen the saved folder. Choose it again.") }
    }

    private fun clearStartingFolder() { rootUri = null; current = null; prefs.edit().remove("tree_uri").apply() }

    private fun showChooseLocationMessage(message: String = "Choose a starting folder to browse files.") {
        list.removeAllViews()
        val empty = LinearLayout(this).apply { orientation = 1; gravity = Gravity.CENTER; setPadding(dp(24), dp(48), dp(24), dp(48)) }
        empty.addView(text("◇", 42f, violet).apply { gravity = Gravity.CENTER })
        empty.addView(text(message, 14f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(16)) })
        val choose = Button(this).apply { text = "Choose starting folder"; setOnClickListener { chooseFolder() } }
        empty.addView(choose)
        list.addView(empty, LinearLayout.LayoutParams(-1, -1))
        pathLabel.text = "No folder selected"; bottomInfo.text = "Storage access is controlled by Android"
    }

    @Deprecated("Compatibility with Android folder picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickCode && resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!; val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            try {
                contentResolver.takePersistableUriPermission(uri, flags)
                val folder = DocumentFile.fromTreeUri(this, uri)
                if (folder == null || !folder.canRead()) { toast("CodaLib couldn't access that folder."); return }
                rootUri = uri; current = folder; prefs.edit().putString("tree_uri", uri.toString()).apply(); showingFavorites = false; showingShortcut = null
                buildSidebar(); refresh(); toast("Starting folder saved")
            } catch (_: Exception) { toast("Folder access couldn't be saved. Choose it again.") }
        } else if (requestCode == pickCode && current == null) showChooseLocationMessage("Selection cancelled. Choose a starting folder to continue.")
    }

    private fun refresh() {
        current?.let { dir -> pathLabel.text = dir.name ?: "Storage"; toolbarTitle.text = if (showingFavorites) "Favorites" else showingShortcut ?: "Files" }
        buildSidebar(); refreshListOnly()
    }

    private fun refreshListOnly() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val dir = current
        if (dir == null) { showChooseLocationMessage(); return }
        var items: List<DocumentFile> = if (showingFavorites) favorites.mapNotNull { uri -> runCatching { DocumentFile.fromSingleUri(this, Uri.parse(uri)) }.getOrNull() }.filter { it.exists() }
        else runCatching { dir.listFiles().toList() }.getOrDefault(emptyList())
        if (searchQuery.isNotBlank()) {
            val found = mutableListOf<DocumentFile>(); collectMatches(dir, searchQuery.lowercase(Locale.getDefault()), found)
            items = found
        }
        if (showingShortcut == "Images") items = items.filter { category(it) == "Images" }
        if (showingShortcut == "Documents") items = items.filter { category(it) == "Documents" }
        if (showingShortcut == "Downloads") items = items.filter { (it.name ?: "").contains("download", true) }
        items = items.filter { filter == "All" || category(it) == filter }
        items = when (sortField) {
            "size" -> items.sortedBy { it.length() }
            "type" -> items.sortedBy { it.type ?: "" }
            "date" -> items.sortedBy { it.lastModified() }
            else -> items.sortedBy { it.name?.lowercase(Locale.getDefault()) ?: "" }
        }
        if (sortField == "name") items = items.sortedWith(compareBy<DocumentFile>({ !it.isDirectory }, { it.name?.lowercase(Locale.getDefault()) ?: "" }))
        if (descending) items = items.reversed()
        currentItems = items
        if (items.isEmpty()) {
            val msg = if (searchQuery.isNotBlank()) "No matching files or folders" else if (showingFavorites) "No favorites yet" else "This folder is empty"
            list.addView(text(msg, 13f, muted).apply { gravity = Gravity.CENTER; setPadding(dp(20), dp(54), dp(20), dp(54)) }, LinearLayout.LayoutParams(-1, -2))
        } else items.forEach { addRow(it) }
        val files = items.count { !it.isDirectory }; val folders = items.count { it.isDirectory }
        val used = items.filter { !it.isDirectory }.sumOf { it.length() }
        val selectedFiles = currentItems.filter { selected.contains(it.uri) }
        val selectedSize = selectedFiles.sumOf { it.length() }
        bottomInfo.text = if (selectionMode) "${selected.size} selected · ${fmt(selectedSize)}" else "$folders folders · $files files     •     Listed size ${fmt(used)}"
        updateSelectionBar()
    }

    private fun collectMatches(dir: DocumentFile, query: String, out: MutableList<DocumentFile>, depth: Int = 0) {
        if (depth > 12 || out.size > 2000) return
        val children = runCatching { dir.listFiles() }.getOrDefault(emptyArray())
        children.forEach { f ->
            if ((f.name ?: "").lowercase(Locale.getDefault()).contains(query)) out.add(f)
            if (f.isDirectory) collectMatches(f, query, out, depth + 1)
        }
    }

    private fun addRow(file: DocumentFile) {
        val isSelected = selected.contains(file.uri)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(4), dp(8), dp(4)); setBackgroundColor(if (isSelected) 0xFF302247.toInt() else plum) }
        val glyph = TextView(this).apply { text = if (file.isDirectory) "▰" else fileGlyph(file.name ?: ""); textSize = 19f; gravity = Gravity.CENTER; setTextColor(if (file.isDirectory) violetSoft else emeraldSoft) }
        row.addView(glyph, LinearLayout.LayoutParams(dp(34), dp(36)))
        val nameColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(5), 0, dp(4), 0) }
        nameColumn.addView(text(file.name ?: "Unnamed", 12f, fg).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE })
        nameColumn.addView(text(if (file.isDirectory) "Folder" else mimeLabel(file.name ?: ""), 9f, muted))
        row.addView(nameColumn, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text(if (file.isDirectory) "—" else fmt(file.length()), 9f, muted), LinearLayout.LayoutParams(dp(62), -2))
        row.addView(text(if (file.isDirectory) "Folder" else extension(file.name ?: ""), 9f, emeraldSoft).apply { maxLines = 1 }, LinearLayout.LayoutParams(dp(60), -2))
        val date = if (file.lastModified() > 0) DateFormat.getDateInstance(DateFormat.SHORT).format(Date(file.lastModified())) else "—"
        row.addView(text(date, 9f, muted), LinearLayout.LayoutParams(dp(82), -2))
        row.addView(TextView(this).apply { text = "⋮"; textSize = 19f; gravity = Gravity.CENTER; setTextColor(muted); setOnClickListener { fileMenu(file) } }, LinearLayout.LayoutParams(dp(24), dp(36)))
        row.setOnClickListener {
            if (selectionMode) toggleSelection(file) else if (file.isDirectory) { current = file; showingFavorites = false; showingShortcut = null; buildSidebar(); refresh() } else open(file)
        }
        row.setOnLongClickListener { if (!selectionMode) selectionMode = true; toggleSelection(file); true }
        list.addView(row)
        list.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun toggleSelection(file: DocumentFile) {
        if (selected.contains(file.uri)) selected.remove(file.uri) else selected.add(file.uri)
        if (selected.isEmpty()) selectionMode = false
        refreshListOnly()
    }

    private fun updateSelectionBar() {
        selectionBar.removeAllViews()
        selectionBar.visibility = if (selectionMode) View.VISIBLE else View.GONE
        if (!selectionMode) return
        selectionBar.addView(text("${selected.size} selected", 12f, fg, true), LinearLayout.LayoutParams(0, -2, 1f))
        listOf("Copy", "Move", "Share", "Delete", "✕").forEach { action ->
            val b = TextView(this).apply { text = action; textSize = 10f; setTextColor(violetSoft); setPadding(dp(6), dp(8), dp(6), dp(8)); setOnClickListener {
                val targets = currentItems.filter { selected.contains(it.uri) }
                when (action) {
                    "Copy" -> { clip = targets.firstOrNull(); moveClip = false; toast("Select a destination, then Paste here") }
                    "Move" -> { clip = targets.firstOrNull(); moveClip = true; toast("Select a destination, then Paste here") }
                    "Share" -> shareItems(targets)
                    "Delete" -> deleteSelected(targets)
                    else -> { selected.clear(); selectionMode = false; refreshListOnly() }
                }
            } }
            selectionBar.addView(b)
        }
    }

    private fun fileGlyph(name: String): String = when (extension(name)) {
        "jpg", "jpeg", "png", "webp", "gif", "bmp", "svg" -> "▧"
        "mp4", "mkv", "mov", "avi" -> "▶"
        "mp3", "wav", "flac", "m4a" -> "♫"
        "pdf", "doc", "docx", "txt", "md", "rtf" -> "▤"
        "zip", "7z", "rar", "tar", "gz" -> "▦"
        "apk" -> "◇"
        else -> "▧"
    }
    private fun extension(name: String) = name.substringAfterLast('.', "FILE").uppercase(Locale.getDefault()).take(5)
    private fun mimeLabel(name: String) = extension(name).lowercase(Locale.getDefault()).let { if (it == "file") "File" else it.uppercase() }
    private fun category(f: DocumentFile): String {
        val e = extension(f.name ?: "").lowercase(Locale.getDefault())
        return when (e) {
            "jpg", "jpeg", "png", "webp", "gif", "bmp", "svg" -> "Images"
            "mp4", "mkv", "mov", "avi", "mp3", "wav", "flac", "m4a" -> "Media"
            "pdf", "doc", "docx", "txt", "md", "rtf", "xls", "xlsx", "ppt", "pptx" -> "Documents"
            "zip", "7z", "rar", "tar", "gz" -> "Archives"
            else -> "Other"
        }
    }
    private fun fmt(b: Long) = when { b < 1024 -> "$b B"; b < 1048576 -> String.format(Locale.US, "%.1f KB", b / 1024.0); else -> String.format(Locale.US, "%.1f MB", b / 1048576.0) }

    private fun createMenu() = AlertDialog.Builder(this).setTitle("Create").setItems(arrayOf("New folder", "New file")) { _, w -> nameDialog(w == 0) }.show()
    private fun nameDialog(folder: Boolean) {
        val input = EditText(this).apply { hint = if (folder) "Folder name" else "example.txt" }
        AlertDialog.Builder(this).setTitle(if (folder) "New folder" else "New file").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Create") { _, _ ->
            val n = input.text.toString().trim(); if (n.isNotBlank() && !n.contains("/")) { val made = if (folder) current?.createDirectory(n) else current?.createFile("text/plain", n); if (made == null) toast("Could not create item") else refresh() }
        }.show()
    }

    private fun fileMenu(f: DocumentFile) {
        val actions = arrayListOf("Open", "Rename", "Copy", "Move", "Add to Favorites", "Details", "Delete")
        if (favorites.contains(f.uri.toString())) actions[4] = "Remove from Favorites"
        AlertDialog.Builder(this).setTitle(f.name ?: "Item").setItems(actions.toTypedArray()) { _, w -> when (actions[w]) {
            "Open" -> if (f.isDirectory) { current = f; refresh() } else open(f)
            "Rename" -> rename(f)
            "Copy" -> { clip = f; moveClip = false; toast("Navigate to a destination, then choose Paste here") }
            "Move" -> { clip = f; moveClip = true; toast("Navigate to a destination, then choose Paste here") }
            "Add to Favorites", "Remove from Favorites" -> { if (!favorites.add(f.uri.toString())) favorites.remove(f.uri.toString()); prefs.edit().putStringSet("favorites", favorites).apply(); refresh() }
            "Details" -> AlertDialog.Builder(this).setTitle(f.name).setMessage("Type: ${if (f.isDirectory) "Folder" else f.type ?: "Unknown"}\nSize: ${fmt(f.length())}\nModified: ${Date(f.lastModified())}\nLocation: ${f.uri}").setPositiveButton("Close", null).show()
            "Delete" -> AlertDialog.Builder(this).setMessage("Delete ${f.name}?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> if (f.delete()) refresh() else toast("Delete failed") }.show()
        } }.show()
    }

    private fun rename(f: DocumentFile) {
        val input = EditText(this).apply { setText(f.name ?: "") }
        AlertDialog.Builder(this).setTitle("Rename").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ -> val n = input.text.toString().trim(); if (n.isNotBlank() && !n.contains("/") && !f.renameTo(n)) toast("Rename failed") else refresh() }.show()
    }

    private fun moreMenu() {
        val choices = arrayOf("Search", "Sort by", "Filter by type", "Paste here", "Change starting folder", "Go to starting folder", "Refresh", "Settings")
        AlertDialog.Builder(this).setTitle("CodaLib").setItems(choices) { _, w -> when (w) {
            0 -> { searchBox.visibility = View.VISIBLE; searchBox.requestFocus() }
            1 -> AlertDialog.Builder(this).setTitle("Sort by").setItems(arrayOf("Name", "Size", "Type", "Date modified", "Reverse order")) { _, s -> if (s == 4) descending = !descending else { sortField = arrayOf("name", "size", "type", "date")[s]; descending = false }; refreshListOnly() }.show()
            2 -> AlertDialog.Builder(this).setTitle("Filter by type").setItems(arrayOf("All", "Images", "Documents", "Media", "Archives", "Other")) { _, s -> filter = arrayOf("All", "Images", "Documents", "Media", "Archives", "Other")[s]; refreshListOnly() }.show()
            3 -> paste()
            4 -> chooseFolder()
            5 -> { current = rootUri?.let { DocumentFile.fromTreeUri(this, it) }; showingFavorites = false; showingShortcut = null; refresh() }
            6 -> refresh()
            7 -> settingsMenu()
        } }.show()
    }

    private fun settingsMenu() {
        AlertDialog.Builder(this).setTitle("Appearance").setItems(arrayOf("System default", "Dark", "Light", "Accent: Violet", "Accent: Emerald")) { _, w ->
            prefs.edit().putString("theme", arrayOf("system", "dark", "light", "violet", "emerald")[w]).apply()
            toast("Appearance preference saved. Full theme switching will be added in a later update.")
        }.show()
    }

    private fun paste() {
        val src = clip ?: run { toast("Clipboard is empty"); return }; val dst = current ?: return
        if (src.uri == dst.uri || (src.isDirectory && dst.uri.toString().startsWith(src.uri.toString()))) { toast("Invalid destination"); return }
        try { val ok = copyInto(src, dst); if (ok && moveClip) { src.delete(); clip = null }; refresh(); toast(if (ok) "Operation complete" else "Copy failed") }
        catch (_: Exception) { toast("Operation failed. Check folder access.") }
    }

    private fun copyInto(src: DocumentFile, dst: DocumentFile): Boolean {
        val name = src.name ?: return false
        if (src.isDirectory) { val target = dst.createDirectory(name) ?: return false; src.listFiles().forEach { copyInto(it, target) }; return true }
        val target = dst.createFile(src.type ?: "application/octet-stream", name) ?: return false
        contentResolver.openInputStream(src.uri).use { input -> contentResolver.openOutputStream(target.uri).use { output -> if (input == null || output == null) return false; input.copyTo(output) } }
        return true
    }

    private fun shareItems(items: List<DocumentFile>) {
        val f = items.firstOrNull() ?: return
        try { val intent = Intent(Intent.ACTION_SEND).setType(f.type ?: "*/*").putExtra(Intent.EXTRA_STREAM, f.uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(Intent.createChooser(intent, "Share file")) }
        catch (_: Exception) { toast("Couldn't share this item") }
    }

    private fun deleteSelected(items: List<DocumentFile>) {
        AlertDialog.Builder(this).setMessage("Delete ${items.size} selected items?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
            val ok = items.all { it.delete() }; selected.clear(); selectionMode = false; refresh(); if (!ok) toast("Some items could not be deleted")
        }.show()
    }

    private fun open(f: DocumentFile) {
        try {
            val mime = f.type ?: when (extension(f.name ?: "").lowercase()) { "txt", "md", "py", "html", "css", "json", "xml", "kt", "java" -> "text/plain"; else -> "*/*" }
            if (mime == "text/plain") {
                val content = contentResolver.openInputStream(f.uri)?.bufferedReader()?.use { it.readText() } ?: ""
                AlertDialog.Builder(this).setTitle(f.name).setMessage(content).setPositiveButton("Close", null).show()
            } else {
                val intent = Intent(Intent.ACTION_VIEW).setDataAndType(f.uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(intent, "Open with"))
            }
        } catch (_: Exception) { toast("No compatible viewer is installed or the file couldn't be opened") }
    }

    override fun onBackPressed() {
        if (selectionMode) { selected.clear(); selectionMode = false; refreshListOnly(); return }
        if (sidebarVisible && !isWide) { sidebar.visibility = View.GONE; sidebarVisible = false; return }
        val root = rootUri?.let { DocumentFile.fromTreeUri(this, it) }
        if (current != null && root != null && current!!.uri != root.uri) { current = root; refresh() } else super.onBackPressed()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
