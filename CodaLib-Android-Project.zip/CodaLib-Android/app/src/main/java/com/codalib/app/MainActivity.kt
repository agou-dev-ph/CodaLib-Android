package com.codalib.app

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var path: TextView
    private lateinit var status: TextView
    private var rootUri: Uri? = null
    private var current: DocumentFile? = null
    private var clip: DocumentFile? = null
    private var moveClip = false
    private val prefs by lazy { getSharedPreferences("codalib", MODE_PRIVATE) }
    private val bg = 0xFF101318.toInt()
    private val panel = 0xFF1A2028.toInt()
    private val fg = 0xFFE8EDF2.toInt()
    private val muted = 0xFF9AA7B4.toInt()
    private val blue = 0xFF65B5F6.toInt()
    private val pickCode = 41
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val base = LinearLayout(this).apply { orientation = 1; setBackgroundColor(bg) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16),dp(10),dp(12),dp(10)); setBackgroundColor(panel) }
        bar.addView(TextView(this).apply { text="CodaLib"; textSize=21f; setTextColor(fg); typeface=android.graphics.Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0,-2,1f))
        tool(bar,"＋") { createMenu() }; tool(bar,"⋮") { moreMenu() }
        base.addView(bar)
        path = TextView(this).apply { textSize=12f; setTextColor(blue); setPadding(dp(16),dp(12),dp(16),dp(12)); setBackgroundColor(0xFF151A20.toInt()); isSingleLine=true; ellipsize=android.text.TextUtils.TruncateAt.MIDDLE }
        base.addView(path)
        base.addView(TextView(this).apply { text="NAME                                                   SIZE / DATE"; textSize=10f; setTextColor(muted); setPadding(dp(16),dp(8),dp(16),dp(8)) })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation=1 }
        scroll.addView(list)
        base.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        status = TextView(this).apply { textSize=11f; setTextColor(muted); setPadding(dp(16),dp(10),dp(16),dp(10)); setBackgroundColor(panel) }
        base.addView(status)
        setContentView(base)
        prefs.getString("tree_uri",null)?.let {
            try { rootUri=Uri.parse(it); current=DocumentFile.fromTreeUri(this,rootUri!!); refresh() } catch (_:Exception) { chooseFolder() }
        } ?: chooseFolder()
    }

    private fun tool(parent: LinearLayout, glyph: String, action: () -> Unit) {
        parent.addView(TextView(this).apply { text=glyph; textSize=25f; gravity=Gravity.CENTER; setTextColor(fg); setPadding(dp(12),0,dp(8),0); setOnClickListener { action() } })
    }

    private fun chooseFolder() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i,pickCode)
    }

    @Deprecated("Compatibility with Android folder picker")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==pickCode && resultCode==RESULT_OK) {
            val uri=data?.data ?: return
            val flags=data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            try { contentResolver.takePersistableUriPermission(uri,flags) } catch (_:Exception) {}
            rootUri=uri; prefs.edit().putString("tree_uri",uri.toString()).apply()
            current=DocumentFile.fromTreeUri(this,uri); refresh()
        } else if(current==null) status.text="Choose your CodaLib folder to begin."
    }

    private fun refresh() {
        val dir=current ?: return
        path.text="📁  ${dir.name ?: "CodaLib"}"
        list.removeAllViews()
        val items=try { dir.listFiles().sortedWith(compareBy<DocumentFile>({!it.isDirectory},{it.name?.lowercase(Locale.getDefault()) ?: ""})) } catch (_:Exception) { emptyList() }
        if(items.isEmpty()) list.addView(TextView(this).apply { text="This folder is empty\nTap ＋ to create a folder or file."; gravity=Gravity.CENTER; textSize=14f; setTextColor(muted); setPadding(dp(20),dp(48),dp(20),dp(48)) })
        items.forEach { addRow(it) }
        status.text="${items.count{it.isDirectory}} folders  •  ${items.count{!it.isDirectory}} files"
    }

    private fun addRow(file:DocumentFile) {
        val row=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; setPadding(dp(14),dp(10),dp(12),dp(10)); setBackgroundColor(bg) }
        row.addView(TextView(this).apply { text=if(file.isDirectory) "📁" else icon(file.name ?: ""); textSize=22f; gravity=Gravity.CENTER },LinearLayout.LayoutParams(dp(42),dp(42)))
        val info=LinearLayout(this).apply { orientation=1 }
        info.addView(TextView(this).apply { text=file.name ?: "Unnamed"; textSize=14f; setTextColor(fg); maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.MIDDLE })
        val size=if(file.isDirectory) "Folder" else fmt(file.length())
        val date=if(file.lastModified()>0) DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(Date(file.lastModified())) else ""
        info.addView(TextView(this).apply { text="$size  •  $date"; textSize=10f; setTextColor(muted) })
        row.addView(info,LinearLayout.LayoutParams(0,-2,1f))
        row.addView(TextView(this).apply { text="⋮"; textSize=22f; setTextColor(muted); setPadding(dp(10),0,0,0); setOnClickListener{fileMenu(file)} })
        row.setOnClickListener { if(file.isDirectory){current=file;refresh()} else open(file) }
        row.setOnLongClickListener { fileMenu(file); true }
        list.addView(row)
        list.addView(View(this).apply{setBackgroundColor(0xFF252C35.toInt())},LinearLayout.LayoutParams(-1,dp(1)))
    }

    private fun icon(n:String)=when(n.substringAfterLast('.', "").lowercase()) {
        "kt","java","c","h","cpp","py","js","ts","html","css","xml","json" -> "📄"
        "zip","7z","rar","tar","gz" -> "🗜️"
        "jpg","jpeg","png","webp","gif" -> "🖼️"
        "pdf" -> "📕"
        else -> "📃"
    }
    private fun fmt(b:Long)=when { b<1024 -> "$b B"; b<1048576 -> String.format(Locale.US,"%.1f KB",b/1024.0); else -> String.format(Locale.US,"%.1f MB",b/1048576.0) }

    private fun createMenu() = AlertDialog.Builder(this).setTitle("Create").setItems(arrayOf("New folder","New file")){_,w->nameDialog(w==0)}.show()
    private fun nameDialog(folder:Boolean) {
        val input=EditText(this).apply{hint=if(folder)"Folder name" else "example.py"}
        AlertDialog.Builder(this).setTitle(if(folder)"New folder" else "New file").setView(input).setNegativeButton("Cancel",null)
            .setPositiveButton("Create"){_,_-> val n=input.text.toString().trim(); if(n.isNotBlank() && !n.contains("/")) {
                val made=if(folder) current?.createDirectory(n) else current?.createFile("application/octet-stream",n)
                if(made==null) toast("Could not create item.") else refresh()
            }}.show()
    }

    private fun fileMenu(f:DocumentFile) {
        AlertDialog.Builder(this).setTitle(f.name ?: "Item").setItems(arrayOf("Open","Rename","Copy","Move","Delete")){_,w->when(w){
            0->if(f.isDirectory){current=f;refresh()}else open(f)
            1->rename(f)
            2->{clip=f;moveClip=false;toast("Copied. Navigate to a destination, then choose Paste here.")}
            3->{clip=f;moveClip=true;toast("Ready to move. Navigate to a destination, then choose Paste here.")}
            4->AlertDialog.Builder(this).setMessage("Delete ${f.name}?").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->if(f.delete())refresh()else toast("Delete failed.")}.show()
        }}.show()
    }
    private fun rename(f:DocumentFile) {
        val input=EditText(this).apply{setText(f.name ?: "")}
        AlertDialog.Builder(this).setTitle("Rename").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->val n=input.text.toString().trim(); if(n.isNotBlank()&&!n.contains("/")&&!f.renameTo(n))toast("Rename failed.") else refresh()}.show()
    }
    private fun moreMenu() {
        AlertDialog.Builder(this).setTitle("CodaLib").setItems(arrayOf("Paste here","Change selected folder","Go to CodaLib root","Refresh")){_,w->when(w){
            0->paste(); 1->chooseFolder(); 2->{current=rootUri?.let{DocumentFile.fromTreeUri(this,it)};refresh()}; 3->refresh()
        }}.show()
    }
    private fun paste() {
        val src=clip ?: run{toast("Clipboard is empty.");return}
        val dst=current ?: return
        if(src.uri==dst.uri || (src.isDirectory && dst.uri.toString().startsWith(src.uri.toString()))){toast("Invalid destination.");return}
        try {
            val ok=copyInto(src,dst)
            if(ok && moveClip){src.delete();clip=null}
            refresh();toast(if(ok)"Operation complete." else "Copy failed.")
        } catch(_:Exception){toast("Operation failed. Check folder access.")}
    }
    private fun copyInto(src:DocumentFile,dst:DocumentFile):Boolean {
        val name=src.name ?: return false
        if(src.isDirectory) {
            val target=dst.createDirectory(name) ?: return false
            src.listFiles().forEach{copyInto(it,target)}
            return true
        }
        val target=dst.createFile(src.type ?: "application/octet-stream",name) ?: return false
        contentResolver.openInputStream(src.uri).use { input ->
            contentResolver.openOutputStream(target.uri).use { output ->
                if(input==null || output==null)return false
                input.copyTo(output)
            }
        }
        return true
    }
    private fun open(f:DocumentFile) {
        try {
            val i=Intent(Intent.ACTION_VIEW).setDataAndType(f.uri,f.type ?: "*/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i,"Open with"))
        } catch(_:Exception){toast("No compatible editor or viewer is installed.")}
    }
    override fun onBackPressed() {
        val root=rootUri?.let{DocumentFile.fromTreeUri(this,it)}
        if(current!=null && root!=null && current!!.uri!=root.uri){current=root;refresh()} else super.onBackPressed()
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
